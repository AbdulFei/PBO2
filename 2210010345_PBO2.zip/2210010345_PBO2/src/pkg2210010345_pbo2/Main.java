/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg2210010345_pbo2;

/**
 *
 * @author Abdul Fei
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new gui.HalamanAwal().setVisible(true);//untuk pemanggilan halaman awal yang mengandul 7 tebel
    }
    
}
